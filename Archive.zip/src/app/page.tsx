import UserForm from "./components/UserForm";

export default function Home() {
  return (
    <div className="App">
        <UserForm />
      </div>
  );
}
